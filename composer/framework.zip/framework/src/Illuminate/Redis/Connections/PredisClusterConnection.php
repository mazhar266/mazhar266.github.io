<?php

namespace Illuminate\Redis\Connections;

class PredisClusterConnection extends PredisConnection
{
    //
}
