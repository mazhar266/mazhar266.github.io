<div class="table">
{{ Illuminate\Mail\Markdown::parse($slot) }}
</div>
